﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CookieController : MonoBehaviour
{
    public Scrollbar HealthBar;  // 체력바 
    public Text ScoreText; // 점수 텍스트
    public Text DieText; //죽음 텍스트

    private Rigidbody2D cookie;   //리지드 바티 2d 쿠키
    public PolygonCollider2D cookieIdle;  
    public PolygonCollider2D cookieSlide;
    private Animator cookieAni;  // 쿠키 애니메이션


    private float POWER = 25.0f;  //쿠키 점프 파워 
    private bool jump = false;  // bool 일때 점프 true
    private bool slide = false;  // bool 일때 슬라이드 false
    private int jumpCount = 0;  
    private int Score = 0;
    private float health = 95f; // 체력 

    private void Start()
    {
        cookie = GetComponent<Rigidbody2D>();
        cookieAni = GetComponent<Animator>();
        ScoreRenew();
        LifeRenew();

        StartCoroutine("NextPage"); // 코루틴 다음 패턴

    }

    private void FixedUpdate()
    {
        if(jumpCount > 0 && jump)
        {
            cookie.velocity = (Vector2.up * POWER); 
            cookieAni.SetInteger("Jump", jumpCount);
            jump = false;
        }
    }

    private void Update()
    {
        health -= 0.004f;
        LifeRenew();
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            cookieAni.SetBool("Slide", true);
            slide = true;
            cookieSlide.enabled = true;
            cookieIdle.enabled = false;
        }

        if (Input.GetKeyUp(KeyCode.DownArrow))
        {
            cookieAni.SetBool("Slide", false);
            slide = false;
            cookieIdle.enabled = true;
            cookieSlide.enabled = false;
        }

        if (Input.GetKeyDown(KeyCode.UpArrow) && jumpCount < 2 && !slide)
        {
            jumpCount++;
            jump = true;
            cookieAni.SetBool("Idle", false);
        }


        if (0 >= HealthBar.size)
        {
            cookieAni.SetBool("Die", true);
            GameManager.instance.gameOver = true;
        }

        if (transform.position.y < -10)
        {
            GameManager.instance.gameOver = true;
        }

        if (GameManager.instance.gameOver)
        {
            DieText.enabled = true;
            LifeRenew();
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            jumpCount = 0;
            cookieAni.SetInteger("Jump", jumpCount);
            cookieAni.SetBool("Idle", true);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Potion"))
        {
            health += 7f;
            Destroy(collision.gameObject);
        }
        if (collision.CompareTag("Trap"))
        {
            cookieAni.SetBool("Crash", true);
            health -= 5;
            LifeRenew();
        }

        if (collision.CompareTag("Pit"))
        {
            GameManager.instance.gameOver = true;
        }

        if (collision.CompareTag("Coin"))
        {
            Score += 12;
            ScoreRenew();
            Destroy(collision.gameObject);
        }

        if (collision.CompareTag("Crystal"))
        {
            Score += 63;
            ScoreRenew();
            Destroy(collision.gameObject);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Trap"))
        {
            cookieAni.SetBool("Crash", false);
        }
    }

    void LifeRenew()
    {
        HealthBar.size = health / 100f;
    }

    void ScoreRenew()
    {
        ScoreText.text = "Score : " + Score.ToString();
    }

    IEnumerator NextPage()
    {
        while (true)
        {
            yield return new WaitForSeconds(15.0f);
            GameManager.instance.stage++;
        }
    }

}
