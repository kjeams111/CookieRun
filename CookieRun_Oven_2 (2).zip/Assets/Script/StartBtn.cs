using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartBtn : MonoBehaviour
{
    public void Start_Btn()
    {
        SceneManager.LoadScene("GameScene");
    }
        
}
