﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScrollManager : MonoBehaviour
{
   
    public float scrollSpeed;
    

    private SpriteRenderer Scroller;
    private Vector2 scrollOffset = Vector2.zero;

    void Start()
    {
        Scroller = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        if (!GameManager.instance.gameOver)
        {
            scrollOffset = Scroller.material.mainTextureOffset;
            scrollOffset.x += (scrollSpeed * Time.deltaTime);
            Scroller.material.mainTextureOffset = scrollOffset;
        }

    
    }
}
